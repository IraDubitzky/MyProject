totalPrice = 0;
let productCount = 0;
let price;
document.getElementById('totalPrice').innerHTML = totalPrice;

function addItem() {

    productCount++;
    let item = document.getElementById('item').value;
    price = +document.getElementById('price').value;
    document.getElementById('products').innerHTML += `<tr><td>${productCount}</td><td>${item}</td><td> ${price} </td><td><button class="btn btn-warning btn-sm" onclick="deleteItem(this, ${price})" id="btnDelete">Delete</button></td></tr>`;
    totalPrice += price;
    document.getElementById('totalPrice').innerHTML = totalPrice + '\u20aa';
    document.getElementById('item').value = "";
    document.getElementById('price').value = "";

}

function deleteItem(button, price) {
    let row = button.closest('tr');
    row.parentNode.removeChild(row);
    totalPrice -= price;
    document.getElementById('totalPrice').innerHTML = totalPrice;
}



